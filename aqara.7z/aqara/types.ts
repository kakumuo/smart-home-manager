


export type DeviceInfo = {
    ipAddress?:string
}

export type AqaraResponse = {
    session:AqaraSession, 
    responseData:any
}

export type AqaraSession = {
    appId:string,
    keyId:string,
    appKey:string,
    nonce:string,
    time:string,
    sign:string

    authCode?:string,
    accessToken?:string,
    expiresIn?:string,
    openId?:string,
    refreshToken?:string,

    timestamp?:number
}

export type AquaraData = {
    intent:string,
    data:any
}

export type AqaraDeviceResourceResult = {
    timeStamp:number,
    resourceId:string,
    value:string,
    subjectId:string
}

export type AqaraDeviceInfoResponse = {
    "parentDid": string,
    "positionId": string,
    "createTime": number,
    "timeZone": string,
    "model": string,
    "updateTime": number,
    "modelType": number,
    "state": number,
    "firmwareVersion": string,
    "deviceName": string,
    "did": string
}