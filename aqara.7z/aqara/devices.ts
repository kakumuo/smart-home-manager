import { SmartDevice, DeviceProperty } from '../device/device.js'
import { AqaraDeviceResourceResult } from './types.js'

export class AqaraDevice extends SmartDevice {
    model?:DeviceProperty<string> = new DeviceProperty<string>("model")
    updateTime?:DeviceProperty<number> = new DeviceProperty<number>("updateTime")
    modelType?:DeviceProperty<number> = new DeviceProperty<number>("modelType")
    state?:DeviceProperty<number> = new DeviceProperty<number>("state")
    firmwareVersion?:DeviceProperty<string> = new DeviceProperty<string>("firmwareVersion")
    deviceName?:DeviceProperty<string> = new DeviceProperty<string>("deviceName")
    deviceId?:DeviceProperty<string> = new DeviceProperty<string>("deviceId")
    deviceStateTimestamp?:DeviceProperty<number> = new DeviceProperty<number>("deviceStateTimestamp")

    constructor(details:any){
        super()
        this.updateDeviceInfo(details)
        this.model = new DeviceProperty<string>("model")

        this.properties.push(this.model)
        this.properties.push(this.updateTime)
        this.properties.push(this.modelType)
        this.properties.push(this.state)
        this.properties.push(this.firmwareVersion)
        this.properties.push(this.deviceName)
        this.properties.push(this.deviceId)
        this.properties.push(this.deviceStateTimestamp)
    }

    updateDeviceInfo = (details:any):void => {
        this.model.set(details.model)
        this.updateTime.set(details.updateTime)
        this.modelType.set(details.modelType)
        this.state.set(details.state)
        this.firmwareVersion.set(details.firmwareVersion)
        this.deviceName.set(details.deviceName)
        this.deviceId.set(details.did)
    }

    updateDeviceState = async(detail:AqaraDeviceResourceResult) => {}
}

export const MOTION_SENSOR_ILLUMINANCE_RID = "0.3.85";
export const MOTION_SENSOR_BATTERY_STATUS_RID = "8.0.9001";
export const MOTION_SENSOR_ILLUMINATION_RID = "0.4.85";
export const MOTION_SENSOR_BATTERY_VOLTAGE_RID = "8.0.2008";
export const MOTION_SENSOR_ZIGBEE_SIGNAL_STRENGTH_RID = "8.0.2007";
export const MOTION_SENSOR_ZIGBEE_CHANNEL_RID = "8.0.2024";
export const MOTION_SENSOR_IDENTIFY_THE_DEVICE_RID = "8.0.2041";
export const MOTION_SENSOR_SAMPLE_PERIOD_RID = "8.0.2097";
export const MOTION_SENSOR_MOTION_STATUS_RID = "3.1.85";

export class AqaraMotionSensor extends AqaraDevice {
    
    lumosity?:DeviceProperty<number> = new DeviceProperty<number>("lumosity")
    presence?:DeviceProperty<boolean> = new DeviceProperty<boolean>("presence")

    constructor(details:any){
        super(details)

        this.properties.push(this.lumosity)
        this.properties.push(this.presence)
    }

    updateDeviceState = async(detail:AqaraDeviceResourceResult) => {
        if(detail.resourceId == MOTION_SENSOR_ILLUMINATION_RID){
            this.lumosity.set(Number.parseInt(detail.value))
        }else if (detail.resourceId == MOTION_SENSOR_MOTION_STATUS_RID){
            this.presence.set(detail.value == "1")
        }

        this.deviceStateTimestamp.set(detail.timeStamp)
    }
}