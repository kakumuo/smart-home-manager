
import { TapoCrypto } from "./tplinkCipher.js";
import { TapoDevice, TapoDeviceKey } from "./types.js";
import * as HTTPS from "https";
import { IncomingHttpHeaders } from 'http';
import * as HTTP from 'http';
import * as LD from 'local-devices'

// another variant is https://n-euw1-wap-gw.tplinkcloud.com
const BASE_URL = 'use1-wap.tplinkcloud.com'

export class TapoAPIClient {
  deviceKey:TapoDeviceKey

  constructor(email: string = process.env.TAPO_USERNAME || "", password: string = process.env.TAPO_PASSWORD || ""){
    this.deviceKey = TapoCrypto.generateKeyPair()
    this.deviceKey.sessionCookie = new Map<string,string>
  }

  execEndpoint = async (data:any, requestOptions:HTTPS.RequestOptions, requestHeaders:IncomingHttpHeaders, useHTTPS:boolean=true):Promise<any> => {
    return new Promise<any>((resolve, reject) => {

        console.log("UseHttp: ", useHTTPS, " Request: ", requestOptions)
        let responseData:string = ""

        // // add proxy
        // requestOptions.path = `${useHTTPS ? "https": "http"}://${requestOptions.hostname}${requestOptions.path}`
        // requestOptions.hostname = '127.0.0.1'
        // requestOptions.port = '8888'
        // requestOptions.method = "CONNECT"

        let req:HTTP.ClientRequest
        const onRequestResponse = (resp:HTTP.IncomingMessage) => {
          resp.on('data', (chunk) => {
            console.log("Received chunk: ", chunk.toString())
            responseData += chunk;
          })

          resp.on('end', () => {
            console.log("End of data")
            resolve(JSON.parse(responseData))
          })   

          console.log("response headers: ", resp.headers)
        }
        if(useHTTPS) req = HTTPS.request(requestOptions, onRequestResponse)
        else req = HTTP.request(requestOptions, onRequestResponse)

        for(let header in requestHeaders){
          req.setHeader(header, requestHeaders[header]);
        }

        console.log(`Data: ${JSON.stringify(data)}`)
        req.write(JSON.stringify(data))
        req.end()
    })
  }

  // execEndpointSecure = async (data:any, requestOptions:HTTPS.RequestOptions, requestHeaders:IncomingHttpHeaders):Promise<any> => {
  //   let deviceKey = this.deviceKey
  //   requestHeaders.cookie = deviceKey.sessionCookie

  //   this.execEndpoint(data, requestOptions, requestHeaders)
  // }

  cloudLogin = async (email: string = process.env.TAPO_USERNAME || "", password: string = process.env.TAPO_PASSWORD || "") => {
    const request = {
      "method": "login",
      "params": {
        "appType": "Tapo_Android",
        "cloudPassword": password,
        "cloudUserName": email,
        "terminalUUID": '00-00-00-00-00-00'
      }
    }

    const requestOptions:HTTPS.RequestOptions = {
      method: "post", 
      hostname: BASE_URL, 
      path: "/"
    }

    const requestHeaders:IncomingHttpHeaders = {
      "content-type":"applicaiton/json"
    }

    const response = await this.execEndpoint(request, requestOptions, requestHeaders)
    console.log("response from cloudLogin(): ", response)
    this.checkError(response);

    this.deviceKey.token = response.result.token
  }

  getDevices = async (): Promise<Array<TapoDevice>> => {
    const request = {
      "method": "getDeviceList",
      "params": {
        "token": this.deviceKey.token
      }
    }

    const requestOptions:HTTPS.RequestOptions = {
      method: "post", 
      hostname: BASE_URL, 
      path: "/"
    }

    const requestHeaders:IncomingHttpHeaders = {
      "content-type":"applicaiton/json"
    }

    const response = await this.execEndpoint(request, requestOptions, requestHeaders)
    this.checkError(response);
    
    const devices:Array<TapoDevice> = new Array()
    response.result.deviceList.forEach((device:TapoDevice) => {
        devices.push(device)
    })

    return devices;
  }

  handshake = async (deviceIp: string) => {
    // format key
    const data ={
			"method":"handshake",
			"params":{
				"key": this.deviceKey.key.toString(),
				"requestTimeMils": 0
			}
		}
  
    const requestOptions:HTTP.RequestOptions = {
      method: "post", 
      hostname: deviceIp, 
      path: "/app"
    }

    const localSeed:Uint8Array = new Uint8Array(16).map(() => Math.floor(Math.random() * 256));

    const requestHeaders:IncomingHttpHeaders = {
      "content-type":"applicaiton/json"
    }

    const response = await this.execEndpoint(data, requestOptions, requestHeaders, false)
    this.checkError(response);
    console.log("handshake response: ", response)
  }

  augmentTapoDevice = async (deviceInfo: TapoDevice): Promise<TapoDevice> => {
    if (this.isTapoDevice(deviceInfo.deviceType)) {
      return {
        ...deviceInfo,
        alias: TapoCrypto.base64Decode(deviceInfo.alias)
      }
    } else {
      return deviceInfo
    }
  }

  isTapoDevice = (deviceType: string) => {
    switch (deviceType) {
      case 'SMART.TAPOBULB':
      return true
      default: return false
    }
  }

  checkError = (responseData: any) => {
    const errorCode = responseData["error_code"];
    if (errorCode) {
      switch (errorCode) {
        case 0: return;
        case 1010: throw new Error("Invalid public key length");
        case 1501: throw new Error("Invalid request or credentials");
        case 1002: throw new Error("Incorrect request");
        case 1003: throw new Error("JSON format error");
        case 20601: throw new Error("Incorrect email or password");
        case 20675: throw new Error("Cloud token expired or invalid");
        case 9999: throw new Error("Device token expired or invalid");
        default: throw new Error(`Unexpected Error Code: ${errorCode} (${responseData["msg"]})`);
      }

    }
  }

  findLocalDevices = (macAddress:any) => {
    
  }

}



// export const loginDevice = async (email: string = process.env.TAPO_USERNAME || "", password: string = process.env.TAPO_PASSWORD || "", device: TapoDevice) =>
//   loginDeviceByIp(email, password, device.ip);

// export const loginDeviceByIp = async (email: string = process.env.TAPO_USERNAME || "", password: string = process.env.TAPO_PASSWORD || "", deviceIp: string):Promise<TapoDeviceKey> => {
//   const deviceKey = await handshake(deviceIp);
//   const loginDeviceRequest =
//     {
//       "method": "login_device",
//       "params": {
//           "username": TapoCrypto.base64Encode(TapoCrypto.shaDigest(email)),
//           "password": TapoCrypto.base64Encode(password)
//      }
//   }

//   const loginDeviceResponse =  await securePassthrough(loginDeviceRequest, deviceKey);
//   deviceKey.token = loginDeviceResponse.token;
//   return deviceKey;
// }

// export const turnOn = async (deviceKey: TapoDeviceKey, deviceOn: boolean = true) => {
//   const turnDeviceOnRequest = {
//     "method": "set_device_info",
//     "params":{
//       "device_on": deviceOn,
//     },
//     "requestTimeMils": (new Date()).getTime(),
//     "terminalUUID": "00-00-00-00-00-00"
//   }
//   await securePassthrough(turnDeviceOnRequest, deviceKey)
// }

// export const turnOff = async (deviceKey: TapoDeviceKey) => {
//   return turnOn(deviceKey, false);
// }

// export const setBrightness = async (deviceKey: TapoDeviceKey, brightnessLevel: number = 100) => {
//   const setBrightnessRequest = {
//     "method": "set_device_info",
//     "params":{
//       "brightness": brightnessLevel,
//     },
//     "requestTimeMils": (new Date()).getTime(),
//     "terminalUUID": "00-00-00-00-00-00"
//   }
//   await securePassthrough(setBrightnessRequest, deviceKey)
// }

// export const setColour = async (deviceKey: TapoDeviceKey, colour: string = 'white') => {
//   const params = await ColorUtils.getColor(colour);

//   const setColourRequest = {
//     "method": "set_device_info",
//     params,
//     "requestTimeMils": (new Date()).getTime(),
//     "terminalUUID": "00-00-00-00-00-00"
//   }
//   await securePassthrough(setColourRequest, deviceKey)
// }

// export const getDeviceInfo = async (deviceKey: TapoDeviceKey): Promise<TapoDeviceInfo> => {
//   const statusRequest = {
//     "method": "get_device_info",
//     "requestTimeMils": (new Date()).getTime(),
//     "terminalUUID": "00-00-00-00-00-00"
//   }
//   return augmentTapoDeviceInfo(await securePassthrough(statusRequest, deviceKey))
// }

// export const getEnergyUsage = async (deviceKey: TapoDeviceKey): Promise<TapoDeviceInfo> => {
//   const statusRequest = {
//     "method": "get_energy_usage"
//   }
//   return securePassthrough(statusRequest, deviceKey)
// }

// export const securePassthrough = async (deviceRequest: any, deviceKey: TapoDeviceKey):Promise<any> => {
//   const encryptedRequest = TapoCrypto.encrypt(deviceRequest, deviceKey)
//   const securePassthroughRequest = {
//     "method": "securePassthrough",
//     "params": {
//         "request": encryptedRequest,
//     }
//   }

//   const response = await axios({
//     method: 'post',
//     url: `http://${deviceKey.deviceIp}/app?token=${deviceKey.token}`,
//     data: securePassthroughRequest,
//     headers: {
//       "Cookie": deviceKey.sessionCookie
//     }
//   })

//   this.checkError(response.data);

//   const decryptedResponse = TapoCrypto.decrypt(response.data.result.response, deviceKey);
//   this.checkError(decryptedResponse);

//   return decryptedResponse.result;
// }

// const tplinkCaAxios = (): AxiosInstance => {
//   const httpsAgent = new https.Agent({
//     rejectUnauthorized: true,
//     ca: tplinkCaCert,
//   })

//   return axios.create({ httpsAgent })
// }

// const augmentTapoDeviceInfo = (deviceInfo: TapoDeviceInfo): TapoDeviceInfo => {
//     return {
//       ...deviceInfo,
//       ssid: TapoCrypto.base64Decode(deviceInfo.ssid),
//       nickname: TapoCrypto.base64Decode(deviceInfo.nickname),
//     }
// }
